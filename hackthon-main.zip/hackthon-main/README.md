# hackthon

# L1
交付項目 (Deliverables)
✅ 弱點清單

✅ 各項弱點說明

驗收標準 (Acceptance Criteria)

            AC1: 使用業界標準SAST工具完成對指定應用程式的完整掃描
            AC2: 提供結構化漏洞報告，包含:
              - 漏洞ID與描述 
              - 風險分級(Critical/High/Medium/Low/Info) 
              - 受影響的程式碼位置(檔案路徑、行號)
              - 針該漏洞的修復建議
            AC3: 報告容易閱讀，至少需有Summary、弱點清單、對應弱點說明三項。
          
技術指標 (Technical Indicators)
漏洞描述準確性 修復建議的可實施性

# L2
目標 (Objective)
提供深入安全分析，並制定完整風險緩解策略

交付項目 (Deliverables)
✅ 各項漏洞實例"真實性"分析

✅ 各項漏洞實例的"CVSS"分析

驗收標準 (Acceptance Criteria)

            AC1: 報告者表達能力/臺風
            AC2: 案例的"真實性"分析完整度與準確度：
                - 每項都有評分
                - 漏洞真實性評估 (真實弱點vs.誤報)
            AC3: 案例的"CVSS"分析邏輯：
                - 每項漏洞的CWE/CVE對應參照
                - CVSS 3.1評分
                - 解釋各向量字串原因，例如利用難度與潛在業務影響評估
          
技術指標 (Technical Indicators)
對弱點理解程度

# L3
目標 (Objective)
實施漏洞修補並驗證安全改進的有效性

交付項目 (Deliverables)
✅ 檢測工具中存在修補後的複掃結果

✅ 開啟SAST結果比較頁面

✅ 修補報告 (Verification report)

驗收標準 (Acceptance Criteria)

            AC1: 高風險(含)以上弱點修補狀況 (15 個都正確修完則滿分)
                - 工具呈現結果符合 5 個Fixed緊急/高風險
            AC2: 中風險弱點各完成一個案例的修補 (SAST結果比較，Filter：Fixed+Severity) 
                - 工具呈現結果符合 5 種不同的中風險Fixed案例，以及說明為什麼挑這 5 個來修
            AC3: 評審抽點中風險(含)以上弱點，學生自舉其中案例進行說明。
                - 符合安全編碼最佳實踐
                - 包含修補說明與程式碼對比
            AC4: 撰寫所有修補的說明報告
                - 緩解措施
                - 實現的方式
          
技術指標 (Technical Indicators)
安全程式開發的技術能力
