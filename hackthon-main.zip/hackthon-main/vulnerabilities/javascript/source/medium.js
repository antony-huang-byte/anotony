// 增加判斷,阻斷異常惡意輸入
function do_something(e) {
    if (typeof e !== 'string' || e.length > 1000) {
        console.warn("Invalid input to do_something");
        return "";
    }
    var t = "";
    for (var n = e.length - 1; n >= 0; n--) {
        t += e[n];
    }
    return t;
}